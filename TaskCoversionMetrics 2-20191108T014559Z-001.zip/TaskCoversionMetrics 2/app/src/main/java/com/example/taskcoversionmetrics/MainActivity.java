package com.example.taskcoversionmetrics;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.renderscript.Sampler;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Conversion con = new Conversion();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }


    @Override
    protected void onRestoreInstanceState(Bundle InState) {
        super.onRestoreInstanceState(InState);

        EditText emile = findViewById(R.id.mile);
        String smile = InState.getString("miles");
        emile.setText(smile);

        EditText efeet = findViewById(R.id.feet);
        String sfeet = InState.getString("feet");
        efeet.setText(sfeet);

        EditText einches = findViewById(R.id.inches);
        String sinches = InState.getString("inches");
        einches.setText(sinches);

        TextView tv = findViewById(R.id.textView);
        String stv = InState.getString("Value");
        tv.setText(stv);


    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        EditText emile = findViewById(R.id.mile);
        String smile = emile.getText().toString();
        EditText efeet = findViewById(R.id.feet);
        String sfeet = efeet.getText().toString();
        EditText einches = findViewById(R.id.inches);
        String sinches = einches.getText().toString();

        TextView tv =  findViewById(R.id.textView);
        String stv = tv.getText().toString();

        outState.putString("miles", smile);
        outState.putString("feet", sfeet);
        outState.putString("inches", sinches);
        outState.putString("Value", stv);

    }

    public void ConverterButton(View v) {
        EditText emile = findViewById(R.id.mile);
        EditText efeet =  findViewById(R.id.feet);
        EditText einches = findViewById(R.id.inches);

        CheckBox cb = findViewById(R.id.CheckBox);

        TextView tv = findViewById(R.id.textView);

        String i="";
        String j="";


        if (cb.isChecked()) {
            if ((!emile.getText().toString().isEmpty()) & efeet.getText().toString().isEmpty() & einches.getText().toString().isEmpty()) {
                i = con.convMetric(emile.getText().toString(), 1);
                j = String.valueOf(Double.parseDouble(i)*0.01);
                tv.setText(i + " cm " + " or " +j + " meters ");

            } else if (emile.getText().toString().isEmpty() & !(efeet.getText().toString().isEmpty()) & einches.getText().toString().isEmpty()) {
                i = con.convMetric(efeet.getText().toString(), 2);
                j = String.valueOf(Double.parseDouble(i)*0.01);
                tv.setText(i + " cm " + " or " + j + " meters ");
            } else {
                i = con.convMetric(einches.getText().toString(), 3);
                j = String.valueOf(Double.parseDouble(i)*0.01);
                tv.setText(i + " cm " + " or " + j + " meters ");
            }
        } else {
            if ((!emile.getText().toString().isEmpty()) & efeet.getText().toString().isEmpty() & einches.getText().toString().isEmpty()) {
                i = con.convMetric(emile.getText().toString(), 1);
                tv.setText(i + " cm ");
            } else if (emile.getText().toString().isEmpty() & !(efeet.getText().toString().isEmpty()) & einches.getText().toString().isEmpty()) {
                i = con.convMetric(efeet.getText().toString(), 2);
                tv.setText(i + " cm ");
            } else {
                i = con.convMetric(einches.getText().toString(), 3);
                tv.setText(i + " cm ");
            }

        }


    }

}
