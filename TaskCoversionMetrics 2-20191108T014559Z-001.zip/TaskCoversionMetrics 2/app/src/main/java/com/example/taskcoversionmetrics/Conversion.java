package com.example.taskcoversionmetrics;

public class Conversion {

    public String convMetric(String st, int i) {

        double d=Double.parseDouble(st);
        int j=i;
        try{

            switch (j) {

            case 1:
                d=d*160934;
                break;

            case 2:
                d = d * 30.48;
                break;

            case 3:
                d = d* 2.54;
            break;
        }
        }
        catch(NumberFormatException nfe){
            return "ERR";
        }
        return String.valueOf(d);
    }
}
